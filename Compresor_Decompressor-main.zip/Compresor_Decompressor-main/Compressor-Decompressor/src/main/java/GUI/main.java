package GUI;


public class main {
    public static void main(String[] args) {

        AppFrame frame = new AppFrame("Compressor-Decompressor");
    }
}
